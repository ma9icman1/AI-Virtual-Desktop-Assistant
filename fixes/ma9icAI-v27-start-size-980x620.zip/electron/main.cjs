const {app, BrowserWindow, ipcMain, screen, desktopCapturer, session, globalShortcut, shell} = require("electron");
const {execFile, spawn} = require("child_process");
const fs = require("fs");
const path = require("path");
const http = require("http");

const port = Number(process.env.MAGIC_PORT || 3210);
const AI_SCREEN_WIDTH = 1280;
const AI_SCREEN_HEIGHT = 800;
let desktopPermission = "none";
let desktopKilled = false;
let speechProcess = null;
let speechWindow = null;
let speechStopRequested = false;
let windowsSpeechProcess = null;
let speechMode = null;
const ollamaWorkingDirectory = process.env.MAGIC_APP_ROOT || process.cwd();
const CUSTOM_OLLAMA_MODEL = "minicpm-magic-assistant:latest";
const BASE_OLLAMA_MODEL = "minicpm-v:latest";
const OLLAMA_COMMAND_TIMEOUT = 5000;
const ollamaDownloadProcesses = new Set();

function getBundledMiniCPMModelfile() {
  const candidates = [
    path.join(app.getAppPath(), "public", "models", "minicpm-magic-assistant", "Modelfile"),
    path.join(app.getAppPath(), "Modelfile"),
  ];
  const source = candidates.find((candidate) => fs.existsSync(candidate));

  if (!source) {
    throw new Error("The bundled MiniCPM Magic Assistant Modelfile is missing from the app package.");
  }

  const targetDir = path.join(
    app.getPath("userData"),
    "models",
    "minicpm-magic-assistant"
  );

  const target = path.join(targetDir, "Modelfile");

  fs.mkdirSync(targetDir, { recursive: true });
  fs.copyFileSync(source, target);

  return target;
}

const supportedOllamaModels = new Set([
  "qwen2.5vl:3b",
  "llama3.2:3b",
  "minicpm-v",
  CUSTOM_OLLAMA_MODEL,
]);

function stopWhisperSpeech() {
  speechStopRequested = true;
  const processes = [speechProcess, windowsSpeechProcess].filter(Boolean);
  speechProcess = null;
  windowsSpeechProcess = null;
  speechMode = null;
  if (!processes.length) return Promise.resolve();

  return new Promise((resolve) => {
    let remaining = processes.length;
    const finishOne = () => {
      remaining -= 1;
      if (remaining <= 0) resolve();
    };
    for (const proc of processes) {
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        finishOne();
      };
      const timeout = setTimeout(() => {
        try { proc.kill(); } catch {}
        finish();
      }, 1500);
      proc.once("exit", () => {
        clearTimeout(timeout);
        finish();
      });
      try { proc.stdin?.write("STOP\n"); } catch { try { proc.kill(); } catch {} finish(); }
    }
  });
}

function resolvePythonCommand() {
  if (process.env.MAGIC_PYTHON) return process.env.MAGIC_PYTHON;
  const candidates = process.platform === "win32" ? ["python", "py", "python3"] : ["python3", "python"];
  for (const candidate of candidates) {
    try {
      const result = require("child_process").execFileSync(
        process.platform === "win32" ? "where.exe" : "which",
        [candidate],
        { encoding: "utf8", windowsHide: true, timeout: 2500 }
      ).trim();
      if (result) return candidate;
    } catch {
      // Try the next Python launcher.
    }
  }
  throw new Error("Python was not found. Install Python 3 and the Whisper dependencies, or set MAGIC_PYTHON to the Python executable.");
}

async function startWhisperProcess(window) {
  await stopWhisperSpeech();
  speechStopRequested = false;
  speechWindow = window;
  const workerPath = path.join(__dirname, "whisper_worker.py");
  let pythonCommand;
  try {
    pythonCommand = resolvePythonCommand();
  } catch (error) {
    if (speechWindow && !speechWindow.isDestroyed()) {
      speechWindow.webContents.send("magic-voice-error", error.message);
    }
    throw error;
  }

  speechProcess = spawn(pythonCommand, [workerPath], {
    windowsHide: true,
    env: { ...process.env, PYTHONUNBUFFERED: "1" },
  });

  return await new Promise((resolve, reject) => {
    let output = "";
    let settled = false;
    const startupTimeout = setTimeout(() => {
      const message = "Whisper microphone startup timed out. Check that Python, faster-whisper, sounddevice, and a Windows microphone are installed.";
      if (speechWindow && !speechWindow.isDestroyed()) {
        speechWindow.webContents.send("magic-voice-error", message);
      }
      try { speechProcess?.kill(); } catch {}
      settleReject(new Error(message));
    }, 30000);

    const settleResolve = () => {
      if (settled) return;
      settled = true;
      clearTimeout(startupTimeout);
      resolve(true);
    };
    const settleReject = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(startupTimeout);
      reject(error instanceof Error ? error : new Error(String(error)));
    };

    speechProcess.stdout.on("data", (chunk) => {
      output += chunk.toString();
      const lines = output.split(/\r?\n/);
      output = lines.pop() || "";
      for (const line of lines) {
        if (!line) continue;
        const [kind, text, confidence] = line.split("|");
        if (kind === "READY") {
          if (speechWindow && !speechWindow.isDestroyed()) {
            speechWindow.webContents.send("magic-voice-ready");
          }
          settleResolve();
          continue;
        }
        if (kind === "SPEECH_ERROR") {
          const message = text || "Whisper speech recognition failed.";
          if (speechWindow && !speechWindow.isDestroyed()) {
            speechWindow.webContents.send("magic-voice-error", message);
          }
          if (!settled) settleReject(new Error(message));
          continue;
        }
        if (kind === "DEVICE") {
          if (speechWindow && !speechWindow.isDestroyed()) {
            speechWindow.webContents.send("magic-voice-device", text || "Default microphone");
          }
          continue;
        }
        if (kind === "TRANSCRIPT" && text && speechWindow && !speechWindow.isDestroyed()) {
          speechWindow.webContents.send("magic-voice-transcript", {
            text,
            confidence: Number(confidence) || 0.8,
          });
        }
        if (kind === "LEVEL" && speechWindow && !speechWindow.isDestroyed()) {
          speechWindow.webContents.send("magic-voice-level", Number(text) || 0);
        }
      }
    });

    speechProcess.stderr.on("data", (chunk) => {
      const message = chunk.toString().trim();
      if (/SPEECH_ERROR\|/i.test(message)) {
        const clean = message.replace(/^.*SPEECH_ERROR\|/i, "");
        if (speechWindow && !speechWindow.isDestroyed()) {
          speechWindow.webContents.send("magic-voice-error", clean);
        }
        if (!settled) settleReject(new Error(clean));
      } else if (message) {
        console.warn("[Whisper]", message);
      }
    });

    speechProcess.once("error", (error) => {
      if (speechWindow && !speechWindow.isDestroyed()) {
        speechWindow.webContents.send("magic-voice-error", error.message);
      }
      speechProcess = null;
      settleReject(error);
    });

    speechProcess.once("exit", (code) => {
      const wasStarting = !settled;
      if (!speechStopRequested && speechWindow && !speechWindow.isDestroyed() && !desktopKilled) {
        speechWindow.webContents.send("magic-voice-error", `Whisper speech recognition stopped (exit code ${code ?? "unknown"}).`);
      }
      speechProcess = null;
      if (wasStarting && !speechStopRequested) {
        settleReject(new Error(`Whisper speech recognition stopped before the microphone became ready (exit code ${code ?? "unknown"}).`));
      }
    });
  });
}

/* desktop execution policy hardening v1 */
function runPowerShell(script, args = []) {
  return new Promise((resolve, reject) => {
    execFile(
      "powershell.exe",
      ["-NoProfile", "-NonInteractive", "-Command", script, ...args],
      { windowsHide: true, timeout: 15000, maxBuffer: 1024 * 1024 },
      (error, stdout, stderr) => {
      if (error) reject(new Error(stderr.trim() || error.message));
      else resolve(stdout.trim());
    });
  });
}

async function executeDesktopAction(action, params = {}) {
  if (desktopKilled || !["one_action", "one_session", "always"].includes(desktopPermission)) {
    throw new Error("Desktop control is not permitted.");
  }

  const display = screen.getPrimaryDisplay();
  const scalePoint = (value, axisSize, aiSize) => {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return 0;
    return params.coordinateSpace === "vision"
      ? Math.round(numeric * axisSize / aiSize)
      : Math.round(numeric);
  };
  const x = scalePoint(params.x, display.size.width, AI_SCREEN_WIDTH);
  const y = scalePoint(params.y, display.size.height, AI_SCREEN_HEIGHT);
  if (action === "LAUNCH_APP") {
    const aliases = {
      brave: ["brave.exe", `${process.env.LOCALAPPDATA}\\BraveSoftware\\Brave-Browser\\Application\\brave.exe`, `${process.env.ProgramFiles}\\BraveSoftware\\Brave-Browser\\Application\\brave.exe`, `${process.env["ProgramFiles(x86)"]}\\BraveSoftware\\Brave-Browser\\Application\\brave.exe`],
      edge: ["msedge.exe", `${process.env["ProgramFiles(x86)"]}\\Microsoft\\Edge\\Application\\msedge.exe`],
      chrome: ["chrome.exe", `${process.env.ProgramFiles}\\Google\\Chrome\\Application\\chrome.exe`],
      firefox: ["firefox.exe", `${process.env.ProgramFiles}\\Mozilla Firefox\\firefox.exe`, `${process.env["ProgramFiles(x86)"]}\\Mozilla Firefox\\firefox.exe`],
      notepad: ["notepad.exe"],
      calculator: ["calc.exe"],
      paint: ["mspaint.exe"],
      explorer: ["explorer.exe"],
      files: ["explorer.exe"],
      terminal: ["wt.exe"],
      taskmgr: ["taskmgr.exe"],
    };
    const requested = String(params.app || "").trim().toLowerCase();
    const candidates = aliases[requested];
    if (!candidates) {
      throw new Error(`Application is not allowed: ${requested || "requested app"}.`);
    }
    const target = candidates.find((candidate) => candidate && fs.existsSync(candidate))
      || candidates.find((candidate) => /\.exe$/i.test(candidate));
    if (!target) throw new Error(`Could not find application: ${requested || "requested app"}.`);
    const child = spawn(target, [], { detached: true, stdio: "ignore", windowsHide: true });
    await new Promise((resolve, reject) => {
      child.once("error", (error) => reject(new Error(`Windows could not launch ${requested || target}: ${error.message}`)));
      child.once("spawn", resolve);
    });
    child.unref();
    if (desktopPermission === "one_action") desktopPermission = "none";
    return;
  }
  if (action === "OPEN_FILE") {
    const filePath = String(params.path || "").trim();
    if (!filePath) throw new Error("No file path was provided.");
    if (!path.isAbsolute(filePath)) {
      throw new Error("Opening a file requires an absolute path.");
    }

    const resolvedPath = path.resolve(filePath);
    const blockedExtensions = new Set([
      ".exe", ".com", ".bat", ".cmd", ".ps1", ".psm1",
      ".vbs", ".vbe", ".js", ".jse", ".wsf", ".wsh",
      ".msi", ".msix", ".appx", ".scr", ".cpl", ".dll",
      ".sys", ".lnk", ".url",
    ]);
    const extension = path.extname(resolvedPath).toLowerCase();
    if (blockedExtensions.has(extension)) {
      throw new Error(`Opening this file type is not allowed: ${extension}`);
    }

    const errorMessage = await shell.openPath(resolvedPath);
    if (errorMessage) throw new Error(`Could not open file: ${errorMessage}`);
    if (desktopPermission === "one_action") desktopPermission = "none";
    return;
  }
  if (action === "NAVIGATE_URL") {
    const url = String(params.url || "").trim();
    if (!/^https?:\/\//i.test(url)) throw new Error("Navigation requires an http or https URL.");
    try {
      const parsed = new URL(url);
      if (!["http:", "https:"].includes(parsed.protocol)) throw new Error();
    } catch {
      throw new Error("Navigation requires a valid http or https URL.");
    }
    const errorMessage = await shell.openExternal(url);
    if (errorMessage) throw new Error(`Could not open URL: ${errorMessage}`);
    if (desktopPermission === "one_action") desktopPermission = "none";
    return;
  }
  const supportedInputActions = new Set([
    "MOVE_MOUSE",
    "CLICK",
    "RIGHT_CLICK",
    "DOUBLE_CLICK",
    "DRAG",
    "SCROLL",
    "TYPE_TEXT",
    "KEY_PRESS",
    "WAIT",
  ]);
  if (!supportedInputActions.has(action)) {
    throw new Error(`Unsupported desktop action: ${String(action)}`);
  }

  const boundedInteger = (value, min, max, label) => {
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || !Number.isInteger(numeric) || numeric < min || numeric > max) {
      throw new Error(`${label} is outside the allowed range.`);
    }
    return numeric;
  };

  if (["MOVE_MOUSE", "CLICK", "RIGHT_CLICK", "DOUBLE_CLICK", "DRAG", "SCROLL"].includes(action)) {
    boundedInteger(params.x, 0, AI_SCREEN_WIDTH - 1, "X coordinate");
    boundedInteger(params.y, 0, AI_SCREEN_HEIGHT - 1, "Y coordinate");
  }
  if (action === "DRAG") {
    boundedInteger(params.endX, 0, AI_SCREEN_WIDTH - 1, "End X coordinate");
    boundedInteger(params.endY, 0, AI_SCREEN_HEIGHT - 1, "End Y coordinate");
  }
  if (action === "SCROLL") {
    boundedInteger(params.amount, -10000, 10000, "Scroll amount");
  }
  if (action === "TYPE_TEXT") {
    const text = String(params.text || "");
    if (text.length > 4000) throw new Error("Text input is limited to 4000 characters.");
  }
  if (action === "KEY_PRESS") {
    const key = String(params.key || "");
    if (!key || key.length > 64) throw new Error("Key input is limited to 64 characters.");
  }
  if (action === "WAIT") {
    boundedInteger(params.ms, 0, 10000, "Wait duration");
  }

  const script = `
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class MagicInput {
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern void keybd_event(byte key, byte scan, uint flags, UIntPtr extra);
  public const uint LEFTDOWN=0x02, LEFTUP=0x04, RIGHTDOWN=0x08, RIGHTUP=0x10, KEYUP=0x02;
}
'@
$action = $args[0]
switch ($action) {
  'MOVE_MOUSE' { [MagicInput]::SetCursorPos([int]$args[1], [int]$args[2]) }
  'CLICK' { [MagicInput]::SetCursorPos([int]$args[1], [int]$args[2]); [MagicInput]::mouse_event(2,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 80; [MagicInput]::mouse_event(4,0,0,0,[UIntPtr]::Zero) }
  'RIGHT_CLICK' { [MagicInput]::SetCursorPos([int]$args[1], [int]$args[2]); [MagicInput]::mouse_event(8,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 80; [MagicInput]::mouse_event(16,0,0,0,[UIntPtr]::Zero) }
  'DOUBLE_CLICK' { [MagicInput]::SetCursorPos([int]$args[1], [int]$args[2]); 1..2 | ForEach-Object { [MagicInput]::mouse_event(2,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 80; [MagicInput]::mouse_event(4,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 80 } }
  'DRAG' { [MagicInput]::SetCursorPos([int]$args[1], [int]$args[2]); [MagicInput]::mouse_event(2,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 100; [MagicInput]::SetCursorPos([int]$args[4], [int]$args[5]); Start-Sleep -Milliseconds 100; [MagicInput]::mouse_event(4,0,0,0,[UIntPtr]::Zero) }
  'SCROLL' { [MagicInput]::SetCursorPos([int]$args[1], [int]$args[2]); Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait($args[3]) }
  'TYPE_TEXT' { Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait($args[1]) }
  'KEY_PRESS' { Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait($args[1]) }
  'WAIT' { Start-Sleep -Milliseconds ([int]$args[1]) }
}`;

  const endX = scalePoint(params.endX, display.size.width, AI_SCREEN_WIDTH);
  const endY = scalePoint(params.endY, display.size.height, AI_SCREEN_HEIGHT);
  const actionArgs = [action, String(x), String(y), String(params.text || params.key || params.app || params.ms || ""), String(endX), String(endY)];
  const result = await runPowerShell(script, actionArgs);
  if (desktopPermission === "one_action") desktopPermission = "none";
  return result;
}

ipcMain.on("magic-window-move", (event, deltaX, deltaY) => {
  assertTrustedRenderer(event);
  const window = BrowserWindow.fromWebContents(event.sender);
  if (!window || !Number.isFinite(deltaX) || !Number.isFinite(deltaY)) return;
  const [x, y] = window.getPosition();
  window.setPosition(Math.round(x + deltaX), Math.round(y + deltaY));
});

ipcMain.on("desktop-control-permission", (event, level) => {
  assertTrustedRenderer(event);
  if (["none", "one_action", "one_session", "always", "deny"].includes(level)) {
    desktopPermission = level;
    desktopKilled = level === "deny";
  }
});

ipcMain.handle("desktop-control-action", async (event, action, params) => {
  assertTrustedRenderer(event);
  return executeDesktopAction(action, params);
});
ipcMain.handle("desktop-capture-screen", async (event) => {
  assertTrustedRenderer(event);
  const window = BrowserWindow.fromWebContents(event.sender);
  const wasVisible = window && !window.isDestroyed() && window.isVisible();
  if (wasVisible) {
    window.hide();
    await new Promise((resolve) => setTimeout(resolve, 120));
  }

  try {
    const display = screen.getPrimaryDisplay();
    const sources = await desktopCapturer.getSources({
      types: ["screen"],
      thumbnailSize: { width: display.size.width, height: display.size.height },
      fetchWindowIcons: false,
    });
    const source = sources.find((candidate) => candidate.display_id === String(display.id)) || sources[0];
    if (!source || source.thumbnail.isEmpty()) {
      throw new Error("Windows did not return a desktop screenshot.");
    }
    const normalized = source.thumbnail.resize({ width: AI_SCREEN_WIDTH, height: AI_SCREEN_HEIGHT, quality: "good" });
    return `data:image/jpeg;base64,${normalized.toJPEG(60).toString("base64")}`;
  } finally {
    if (wasVisible && window && !window.isDestroyed()) window.show();
  }
});

function spawnWindowsSpeech(window) {
  const scriptPath = path.join(__dirname, "windows_speech.ps1");
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(scriptPath)) return reject(new Error("Windows speech fallback script is missing."));
    speechWindow = window;
    speechStopRequested = false;
    const proc = spawn("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", scriptPath], {
      windowsHide: true,
      stdio: ["pipe", "pipe", "pipe"],
      env: process.env,
    });
    windowsSpeechProcess = proc;
    speechMode = "windows";
    let output = "";
    let settled = false;
    const timeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      try { proc.kill(); } catch {}
      reject(new Error("Windows microphone startup timed out."));
    }, 8000);
    const resolveReady = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      resolve(true);
    };
    const rejectStart = (e) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      reject(e instanceof Error ? e : new Error(String(e)));
    };
    proc.stdout.on("data", chunk => {
      output += chunk.toString();
      const lines = output.split(/\r?\n/); output = lines.pop() || "";
      for (const line of lines) {
        if (!line) continue;
        const [kind, text, confidence] = line.split("|");
        if (kind === "READY") { window.webContents.send("magic-voice-device", "Windows default microphone"); window.webContents.send("magic-voice-ready"); resolveReady(); }
        else if (kind === "TRANSCRIPT" && text) window.webContents.send("magic-voice-transcript", {text, confidence: Number(confidence) || 0.8});
        else if (kind === "LEVEL") window.webContents.send("magic-voice-level", Number(text) || 0);
        else if (kind === "SPEECH_ERROR") { window.webContents.send("magic-voice-error", text || "Windows speech recognition failed."); rejectStart(new Error(text || "Windows speech recognition failed.")); }
      }
    });
    proc.stderr.on("data", chunk => { const m=chunk.toString().trim(); if(m) console.warn("[Windows Speech]",m); });
    proc.once("error", e => { window.webContents.send("magic-voice-error", e.message); rejectStart(e); });
    proc.once("exit", code => { if (!settled && !speechStopRequested) rejectStart(new Error(`Windows speech process stopped (exit code ${code ?? "unknown"}).`)); });
  });
}

async function startWhisperSpeech(window) {
  try {
    return await startWhisperProcess(window);
  } catch (error) {
    console.warn("[ma9icAI voice] Whisper unavailable, trying Windows Speech fallback:", error.message);
    try { await stopWhisperSpeech(); } catch {}
    return await spawnWindowsSpeech(window);
  }
}

ipcMain.handle("magic-voice-start", async (event) => {
  assertTrustedRenderer(event);
  return startWhisperSpeech(BrowserWindow.fromWebContents(event.sender));
});
ipcMain.on("magic-voice-stop", (event) => {
  assertTrustedRenderer(event);
  stopWhisperSpeech();
});
ipcMain.on("desktop-control-kill", (event) => {
  assertTrustedRenderer(event);
  desktopKilled = true;
  desktopPermission = "none";
});

ipcMain.on("magic-window-close", (event) => {
  assertTrustedRenderer(event);
  BrowserWindow.fromWebContents(event.sender)?.close();
});
ipcMain.on("magic-window-minimize", (event) => {
  assertTrustedRenderer(event);
  BrowserWindow.fromWebContents(event.sender)?.minimize();
});

ipcMain.on("magic-window-toggle-maximize", (event) => {
  assertTrustedRenderer(event);
  const window = BrowserWindow.fromWebContents(event.sender);
  if (!window) return;
  if (window.isMaximized()) window.unmaximize();
  else window.maximize();
});

function findOllamaCommand() {
  return new Promise((resolve, reject) => {
    const commonPaths = [
      process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, "Programs", "Ollama", "ollama.exe"),
      process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, "Ollama", "ollama.exe"),
      process.env.ProgramFiles && path.join(process.env.ProgramFiles, "Ollama", "ollama.exe"),
      process.env["ProgramFiles(x86)"] && path.join(process.env["ProgramFiles(x86)"], "Ollama", "ollama.exe"),
    ].filter(Boolean);

    const existing = commonPaths.find((candidate) => fs.existsSync(candidate));
    if (existing) {
      resolve(existing);
      return;
    }

    execFile("where.exe", ["ollama"], { windowsHide: true, timeout: OLLAMA_COMMAND_TIMEOUT }, (error, stdout) => {
      if (error || !stdout.trim()) {
        reject(new Error("Ollama was not found on Windows. Install Ollama or add ollama.exe to PATH."));
        return;
      }
      resolve(stdout.trim().split(/\r?\n/)[0].trim());
    });
  });
}

function isOllamaOnline() {
  return new Promise((resolve) => {
    const request = http.get("http://127.0.0.1:11434/api/tags", (response) => {
      response.resume();
      resolve(Boolean(response.statusCode && response.statusCode >= 200 && response.statusCode < 500));
    });
    request.setTimeout(1200, () => { request.destroy(); resolve(false); });
    request.on("error", () => resolve(false));
  });
}

async function ensureOllamaServer() {
  if (await isOllamaOnline()) return true;
  try {
    const ollamaPath = await findOllamaCommand();
    const child = spawn(ollamaPath, ["serve"], {
      windowsHide: true,
      detached: true,
      stdio: "ignore",
      cwd: ollamaWorkingDirectory,
      shell: false,
    });
    child.unref();
    for (let attempt = 0; attempt < 20; attempt += 1) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      if (await isOllamaOnline()) return true;
    }
  } catch (error) {
    console.warn("[Ollama] Could not auto-start Ollama:", error?.message || error);
  }
  return false;
}

function spawnOllama(ollamaPath, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(ollamaPath, args, {
      windowsHide: options.windowsHide !== false,
      detached: false,
      stdio: options.capture ? ["ignore", "pipe", "pipe"] : "ignore",
      cwd: ollamaWorkingDirectory,
      shell: false,
    });

    child.once("spawn", () => resolve(child));
    child.once("error", (error) => reject(new Error(`Could not launch Ollama: ${error.message}`)));
  });
}

async function startOllamaService() {
  if (await isOllamaOnline()) return { online: true, started: false };
  const ollamaPath = await findOllamaCommand();
  const child = await spawnOllama(ollamaPath, ["serve"], { windowsHide: true });
  child.unref();
  for (let attempt = 0; attempt < 30; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 400));
    if (await isOllamaOnline()) return { online: true, started: true };
  }
  return { online: false, started: true };
}

async function launchOllamaDownload(model, sender, customModel = null, modelfile = null) {
  const ollamaPath = await findOllamaCommand();
  const pull = await spawnOllama(ollamaPath, ["pull", model], { windowsHide: true, capture: true });
  ollamaDownloadProcesses.add(pull);

  const send = (payload) => {
    try {
      if (sender && !sender.isDestroyed()) sender.send("magic-ollama-progress", payload);
    } catch {}
  };

  const forward = (chunk) => {
    const line = String(chunk || "").trim();
    if (line) send({ model, text: line });
  };
  pull.stdout?.on("data", forward);
  pull.stderr?.on("data", forward);
  send({ model, state: "downloading", text: `Downloading ${model}...` });

  pull.once("error", (error) => {
    ollamaDownloadProcesses.delete(pull);
    send({ model, state: "error", text: error.message });
  });

  pull.once("close", async (code) => {
    ollamaDownloadProcesses.delete(pull);
    if (code !== 0) {
      send({ model, state: "error", text: `Ollama download exited with code ${code}.` });
      return;
    }

    if (customModel && modelfile) {
      try {
        send({ model: customModel, state: "creating", text: `Creating ${customModel}...` });
        const create = await spawnOllama(ollamaPath, ["create", customModel, "-f", modelfile], { windowsHide: true, capture: true });
        ollamaDownloadProcesses.add(create);
        create.stdout?.on("data", forward);
        create.stderr?.on("data", forward);
        create.once("close", (createCode) => {
          ollamaDownloadProcesses.delete(create);
          send(createCode === 0
            ? { model: customModel, state: "complete", text: `${customModel} is installed.` }
            : { model: customModel, state: "error", text: `Ollama model creation exited with code ${createCode}.` });
        });
        create.once("error", (error) => {
          ollamaDownloadProcesses.delete(create);
          send({ model: customModel, state: "error", text: error.message });
        });
      } catch (error) {
        send({ model: customModel, state: "error", text: error?.message || "Could not create custom model." });
      }
      return;
    }

    send({ model, state: "complete", text: `${model} is installed.` });
  });
}

ipcMain.handle("magic-ollama-start", async (event) => {
  assertTrustedRenderer(event);
  try {
    const status = await startOllamaService();
    if (!status.online) {
      return { ok: false, error: "Ollama was found, but its local service did not become available at http://127.0.0.1:11434." };
    }
    const response = await fetch("http://127.0.0.1:11434/api/tags", { signal: AbortSignal.timeout(3000) });
    const data = await response.json();
    return { ok: true, started: status.started, models: Array.isArray(data.models) ? data.models : [] };
  } catch (error) {
    return { ok: false, error: error?.message || "Could not start Ollama." };
  }
});

ipcMain.handle("magic-ollama-download", async (event, model) => {
  assertTrustedRenderer(event);
  if (typeof model !== "string" || !supportedOllamaModels.has(model)) {
    return { ok: false, error: "That Ollama model is not available in the download menu." };
  }
  try {
    const started = await startOllamaService();
    if (!started.online) {
      return { ok: false, error: "Ollama could not be started. Make sure Ollama is installed." };
    }
    const modelFile = model === CUSTOM_OLLAMA_MODEL ? getBundledMiniCPMModelfile() : null;
    await launchOllamaDownload(model === CUSTOM_OLLAMA_MODEL ? BASE_OLLAMA_MODEL : model, event.sender, CUSTOM_OLLAMA_MODEL === model ? CUSTOM_OLLAMA_MODEL : null, modelFile);
    return { ok: true, state: "downloading" };
  } catch (error) {
    return { ok: false, error: error?.message || "Could not start the model download." };
  }
});

ipcMain.on("magic-window-layout", (event, overlayMode) => {
  assertTrustedRenderer(event);
  const window = BrowserWindow.fromWebContents(event.sender);
  if (!window || typeof overlayMode !== "boolean") return;

  if (overlayMode) {
    const workArea = screen.getPrimaryDisplay().workArea;
    const width = 430;
    const height = 620;
    window.setMinimumSize(320, 420);
    window.setBounds({
      x: workArea.x + workArea.width - width - 18,
      y: workArea.y + workArea.height - height,
      width,
      height,
    });
  } else {
    window.setMinimumSize(480, 260);
    window.setBounds({
      x: Math.max(0, Math.round((screen.getPrimaryDisplay().workArea.width - 480) / 2)),
      y: Math.max(0, Math.round((screen.getPrimaryDisplay().workArea.height - 280) / 2)),
      width: 1280,
      height: 820,
    });
  }
});

/* trusted renderer IPC hardening v1 */

function assertTrustedRenderer(event) {

  const sender = event?.sender;

  const frameUrl = event?.senderFrame?.url || sender?.getURL?.() || "";

  if (!sender || !/^http:\/\/127\.0\.0\.1:\d+\//i.test(frameUrl)) {

    throw new Error("Untrusted renderer.");

  }

  const window = BrowserWindow.fromWebContents(sender);

  if (!window || window.isDestroyed()) {

    throw new Error("Renderer window is unavailable.");

  }

  return window;

}

function waitForServer(url, attempts = 80) {
  return new Promise((resolve, reject) => {
    const check = () => {
      const request = http.get(url, (response) => {
        response.resume();
        resolve();
      });
      request.on("error", () => {
        if (attempts-- <= 0) {
          reject(new Error("Magic AI server did not start in time."));
          return;
        }
        setTimeout(check, 250);
      });
    };
    check();
  });
}

async function createWindow() {
  process.env.NODE_ENV = "production";
  const logPath = path.join(app.getPath("userData"), "startup.log");
  const log = (message) => {
    try { fs.appendFileSync(logPath, `[${new Date().toISOString()}] ${message}\n`); } catch {}
    console.log(message);
  };
  process.on("uncaughtException", (error) => log(`UNCAUGHT: ${error?.stack || error}`));
  process.on("unhandledRejection", (error) => log(`UNHANDLED: ${error?.stack || error}`));
  process.env.MAGIC_APP_ROOT = app.getAppPath();
  process.env.PORT = String(port);
  const serverPath = path.join(app.getAppPath(), "dist", "server.cjs");
  if (!fs.existsSync(serverPath)) {
    throw new Error(`Built server is missing: ${serverPath}. Run npm run build before starting ma9icAI.`);
  }
  require(serverPath);

  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
    callback(permission === "media" || permission === "notifications");
  });
  session.defaultSession.setPermissionCheckHandler((_webContents, permission) => {
    return permission === "media" || permission === "notifications";
  });

  session.defaultSession.setDisplayMediaRequestHandler(async (_request, callback) => {
    try {
      const sources = await desktopCapturer.getSources({ types: ["screen"] });
      const primarySource = sources.find((source) => source.display_id) || sources[0];
      callback(primarySource ? { video: primarySource } : {});
    } catch (error) {
      console.error("Unable to select a desktop capture source:", error);
      callback({});
    }
  });

  try {
    await waitForServer(`http://127.0.0.1:${port}/api/health`);
    void ensureOllamaServer();
  } catch (error) {
    log(`SERVER START FAILED: ${error?.stack || error}`);
    throw error;
  }

  globalShortcut.register("CommandOrControl+Alt+Escape", () => {
    desktopKilled = true;
    desktopPermission = "none";
  });

  const window = new BrowserWindow({
    width: 980,
    height: 620,
    minWidth: 980,
    minHeight: 620,
    center: true,
    transparent: false,
    frame: false,
    hasShadow: false,
    alwaysOnTop: true,
    backgroundColor: "#020611",
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      preload: path.join(app.getAppPath(), "electron", "preload.cjs"),
    },
  });

  window.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) {
      void shell.openExternal(url);
    }
    return { action: "deny" };
  });

  window.webContents.on("will-navigate", (event, url) => {
    const allowedPrefix = `http://127.0.0.1:${port}/`;
    if (!url.startsWith(allowedPrefix)) {
      event.preventDefault();
      if (/^https?:\/\//i.test(url)) {
        void shell.openExternal(url);
      }
    }
  });

  window.webContents.on("did-fail-load", (_event, errorCode, errorDescription, validatedURL) => {
    log(`RENDERER LOAD FAILED ${errorCode}: ${errorDescription} ${validatedURL}`);
  });
  window.webContents.on("render-process-gone", (_event, details) => {
    log(`RENDERER GONE: ${JSON.stringify(details)}`);
  });
  window.webContents.on("console-message", (_event, level, message, line, sourceId) => {
    log(`RENDERER CONSOLE [${level}] ${message} (${sourceId}:${line})`);
  });
  try {
    await session.defaultSession.clearCache();
  } catch (error) {
    log(`CACHE CLEAR FAILED: ${error?.message || error}`);
  }
  await window.loadURL(`http://127.0.0.1:${port}/?desktop=1`);
}

app.whenReady().then(createWindow).catch((error) => {
  console.error(error);
  try {
    const message = error?.stack || error?.message || String(error);
    const dialog = require("electron").dialog;
    void dialog.showMessageBox({
      type: "error",
      title: "ma9icAI could not start",
      message: "ma9icAI could not open the main window.",
      detail: message,
      buttons: ["OK"],
    }).finally(() => app.quit());
  } catch {
    app.quit();
  }
});

app.on("window-all-closed", () => {
  stopWhisperSpeech();
  globalShortcut.unregisterAll();
  if (process.platform !== "darwin") app.quit();
});
