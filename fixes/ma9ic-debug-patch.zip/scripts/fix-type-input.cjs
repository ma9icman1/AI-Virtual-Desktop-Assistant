const fs = require("fs");
const path = require("path");
const electronFile = path.join(process.cwd(), "electron", "main.cjs");
if (!fs.existsSync(electronFile)) throw new Error("[desktop-input] electron/main.cjs not found");
const text = fs.readFileSync(electronFile, "utf8");
if (/['"]TYPE_TEXT['"]\s*\{[\s\S]*?scriptArgs\[3\]/.test(text)) {
  console.log("[desktop-input] TYPE_TEXT/debug handler already present; skipped.");
  process.exit(0);
}
console.log("[desktop-input] No compatible TYPE_TEXT handler found. The debug main.cjs supplied with this patch already contains one.");
